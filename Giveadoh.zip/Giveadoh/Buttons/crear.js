const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionFlagsBits, Client, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder,  PermissionsBitField} = require('discord.js');

module.exports = {
    data: {
        name: `claim`,
    },
    async execute(interaction, client) {

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return await interaction.reply({ content: "No tienes suficientes permisos", ephemeral: true });
        }
      
        const embed = new EmbedBuilder()
        .setTitle("Sistema tickets")
        .setDescription(`El ticket le pertence a: <@${interaction.user.id}>`)
        .setColor("Aqua")

        interaction.reply({ embeds: [embed] })

    },
};