const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionFlagsBits, Client, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
  developer: true,
  data: new SlashCommandBuilder()
    .setName("sistema-tickets")
    .setDescription("Creare un sistema de tickets!")
    .addChannelOption(option => 
    option.setName('canal').setDescription('Menciona un canal para enviar el sistema').setRequired(true)
    ),
  /**
   *
   * @param {ChatInputCommandInteraction} interaction
   */
  execute(interaction, client) {
  
  const canal = interaction.options.getChannel("canal")

      const embed = new EmbedBuilder()
      .setTitle("Sistema de tickets")
      .setColor("Aqua")
      .setDescription("Presiona el boton y crea un ticket")

    const button = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
    .setCustomId("ticket")
    .setLabel("Crear ticket")
    .setStyle(ButtonStyle.Primary)

      
    )
    
    interaction.reply({ content: `Sistema de tickets enviado coorectamente`, ephemeral: true});

      canal.send({ embeds: [embed], components: [button] })
    
  },
};