const { Client, GatewayIntentBits, Partials, Collection, Events, AuditLogEvent, EmbedBuilder, Discord, } = require("discord.js");
const { Guilds, GuildMembers, GuildMessages } = GatewayIntentBits;
const { User, Message, GuildMember, ThreadMember } = Partials

const client = new Client({
    intents: 3276799, 
    parials: [User, Message, GuildMember, ThreadMember]   
});

const { loadEvents } = require("./Handlers/eventHandler");
const { loadButtons } = require("./Handlers/buttonHandler")

client.config = require("./config.json");
client.events = new Collection();
client.commands = new Collection();
client.buttons = new Collection();

loadEvents(client);
loadButtons(client);


client.login(client.config.token);

client.on("interactionCreate", async (interaction) => {
    if(interaction.isButton()) {
      if(interaction.customId === "close") {
  
        
        const embed = new EmbedBuilder()
          .setTitle("Sistema de ticket")
          .setDescription(`El ticket se cerrara en 5segundos`)
          .setColor("Aqua")
  
        
        return interaction.reply({ embeds: [embed] })
  
        
          && setTimeout(() => {
        interaction.channel.delete(`${interaction.channels}`)
          }, 5000)
  
      }
    }
  })